First run q_learn_two_state.m to run a Q-learning agent in a two-state environment. Then run, the meta parameter estimation code as:
[alpha, beta, gamma] = get_metaparameters_for_two_state(as, rs, ss)
